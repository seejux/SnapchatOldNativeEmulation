class EmulatorError(Exception):
    pass
