class SymbolResolved:

    def __init__(self, address, symbol):
        self.address = address
        self.symbol = symbol
